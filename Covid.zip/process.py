"""
This module is responsible for processing the data.  Each function in this module will take a list of records,
process it and return the desired result.
"""

"""
Task 16 - 20: Write suitable functions to process the data.

Each of the functions below should follow the pattern:
- Take a list of records (where each record is a list of data values) as a parameter.
- Process the list of records appropriately.  You may use the module 'tui' to retrieve any additional information 
required from the user to complete the processing.
- Return a suitable result

The required functions are as follows:
- Retrieve the total number of records that have been loaded.
- Retrieve a record with the serial number as specified by the user.
- Retrieve the records for the observation dates as specified by the user.
- Retrieve all of the records grouped by the country/region.
- Retrieve a summary of all of the records. This should include the following information for each country/region:
    - the total number of confirmed cases
    - the total number of deaths
    - the total number of recoveries

 
"""
import csv
import tui

def load_record(record):
  with open("covid_19_data.csv") as dataset:
    csv_reader = csv.reader(dataset)
    header = next(csv_reader)
    record=[]
    for line in csv_reader:
     #confirmed = int(line[6].strip())
      record.append(line)
  tui.total_records(len(record))    
    #total=sum(total)

def add_specific_Serialnumber(record):
  with open("covid_19_data.csv") as file:
    csv_reader = csv.reader(file)
    header = next(csv_reader) 
    SN = (tui.serial_number())-1
    record=[]
    for line in csv_reader:
      record.append(line)
    record=record[SN] 
    tui.display_record(record,[0,1,2,3,4,5,6,7])
        
def add_specific_Observationdate(record):
  with open("covid_19_data.csv") as dataset:
     csv_reader = csv.reader(dataset)
     header = next(csv_reader)
     OD=tui.observation_dates()
     record=[]
     for line in csv_reader:
       if OD==line[1]:
         record.append([line[0],line[1],line[2],line[3],line[4],line[4],line[6],line[7]])
     tui.display_records(record,[0,1,2,3,4,5,6,7])
def countryrecord(record):
  with open("covid_19_data.csv") as dataset:
    csv_reader = csv.reader(dataset)
    header = next(csv_reader)
    response=str(input("which country"))
    record=[]
    for line in csv_reader:        
      if line[3] in response:
         record.append([line[0],line[1],line[2],line[3],line[4],line[4],line[6],line[7]])
    tui.display_records(record,[0,1,2,3,4,5,6,7])
def summary(record):
  with open("covid_19_data.csv") as dataset:
    csv_reader = csv.reader(dataset)
    header = next(csv_reader)
    
    for line in csv_reader:
       record.append([line[5]])
    confirmed=0
    j=0
    for j in range(0,len(record)):
       confirmed=int(confirmed) + int(record[j])
       j+=1
    print(confirmed)
  with open("covid_19_data.csv") as dataset:
    csv_reader = csv.reader(dataset)
    header = next(csv_reader)  
    for line in csv_reader:
      record.append([line[6]]) 
    Deaths=0
    j=0
    for j in range(0,len(record)):
       Deaths=int(Deaths) + int(record[j])
       j+=1
    print(Deaths) 
   with open("covid_19_data.csv") as dataset:
    csv_reader = csv.reader(dataset)
    header = next(csv_reader)  
    for line in csv_reader:
      record.append([line[6]]) 
    Recovered=0
    j=0
    for j in range(0,len(record)):
      Recovered=int(Recovered) + int(record[j])
      j+=1
    print(Recoverd)  