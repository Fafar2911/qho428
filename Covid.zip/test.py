print("HI")
import csv 
def run():
 Confirmed=[]
 with open('covid_19_data.csv') as file:
   csv_reader = csv.reader(file)
   csv.header = next(csv_reader)
   for line in csv_reader:
      # extract required values using appropriate indexes
     Confirmed = line[6].strip()
   print("hello") 
   print(Confirmed)
   #print(" There are %d records in the data set."%(num_records))
run()