"""
This module is responsible for visualising the data using Matplotlib.
"""

"""
Task 22 - 24: Write suitable functions to visualise the data as follows:

- Display the number of confirmed cases per country/region using a pie chart
- Display the top 5 countries for deaths using a bar chart
- Display a suitable (animated) visualisation to show how the number of confirmed cases, deaths and recovery change over
time. This could focus on a specific country or countries.

Each function should visualise the data using Matplotlib.
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.animation as animation
def pie_chart():
 df =  pd.read_csv('covid_19_data.csv')
 country_data = df["Country/Region"]
 confirmed_data = df["Confirmed"]
 colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#8c564b"]

 plt.pie(confirmed_data, labels=country_data,autopct="%1.1f%%", colors=colors)
 plt.title("confirmed records sorted by country")
 plt.show(block = False)
 plt.pause(0.01)
 input()
 plt.close()

def bar_chart():
 data = pd.read_csv('covid_19_data.csv')
 sorted_data = data.sort_values(by='Deaths', ascending=False)
 print(sorted_data.head(5))
 df = pd.DataFrame(sorted_data.head(5))
 X = list(df.iloc[:,3])
 print(X)
 Y = list(df.iloc[:,6])
 print(Y)
 plt.bar(X, Y, color='g')
 plt.title("Top 5 countries with max deaths")
 plt.xlabel("country")
 plt.ylabel("Number of deaths")
 plt.show()

def animation():
  data = pd.read_csv('covid_19_data.csv')
  date = data['ObservationDate']
  confirmed = data['Confirmed']
  death = data['Deaths']
  Recovered = data['Recovered']
  fig = plt.figure()
  ax1 = fig.add_subplot(111)

  def animate(i):
    ax1.clear()
    ax1.plot(date, confirmed, label = 'confirmed')
    ax1.plot(date, death, label = 'deaths')
    ax1.plot(date, Recovered, label = 'Recovered')
    ax1.legend(loc = 'upper left')
    ax1.set_xlim([date.iloc[0], date.iloc[-1]])
    ax1.set_ylim(0,6000)
    ani = animation.FuncAnimation(fig, animate, interval = 1000)
    plt.show()

 

